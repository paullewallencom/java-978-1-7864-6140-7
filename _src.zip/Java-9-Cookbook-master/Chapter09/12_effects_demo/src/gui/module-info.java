module gui{
	requires javafx.controls;
	requires javafx.graphics;

	opens com.packt;
}
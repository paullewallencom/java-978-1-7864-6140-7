module gui{
	requires javafx.controls;
	requires javafx.media;

	opens com.packt;
}
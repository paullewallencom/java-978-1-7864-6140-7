module gui{
	requires javafx.controls;
	requires javafx.graphics;
	requires java.desktop;
}
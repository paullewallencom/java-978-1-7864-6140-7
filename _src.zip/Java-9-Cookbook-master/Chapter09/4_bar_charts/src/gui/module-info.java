module gui{
	requires javafx.graphics;
	requires javafx.controls;

	requires student.processor;

	opens com.packt;
}
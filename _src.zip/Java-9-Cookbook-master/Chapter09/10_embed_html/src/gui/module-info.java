module gui{
	requires javafx.controls;
	requires javafx.web;

	opens com.packt;
}
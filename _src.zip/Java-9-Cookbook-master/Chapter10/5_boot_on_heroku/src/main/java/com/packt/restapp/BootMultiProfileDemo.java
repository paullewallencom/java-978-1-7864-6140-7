package com.packt.restapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMultiProfileDemo {

	public static void main(String[] args) {
		SpringApplication.run(BootMultiProfileDemo.class, args);
	}
}

module embedded.nashorn{
    requires java.scripting;
    requires jdk.scripting.nashorn;
}
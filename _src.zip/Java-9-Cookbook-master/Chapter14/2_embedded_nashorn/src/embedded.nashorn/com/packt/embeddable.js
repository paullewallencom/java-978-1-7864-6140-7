function difference(a, b){
    return a - b;
}

function multiple ( a , b){
    return a * b;
}

function remainder(dividend, divisor){
    return dividend % divisor;
}

function divide(dividend, divisor){
    return dividend / divisor;
}
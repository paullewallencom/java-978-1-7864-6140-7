function helloViaJjs(){
    print("Hello via JJS using Nashorn");
}

helloViaJjs();
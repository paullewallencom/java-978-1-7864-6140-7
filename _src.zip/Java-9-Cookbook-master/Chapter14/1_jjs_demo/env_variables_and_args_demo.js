print(`Number of arguments ${$ARG.length}`);
print(`PATH variable: ${$ENV['PATH']}`);
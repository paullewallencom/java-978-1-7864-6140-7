var files = $EXEC("dir").split("\n");
for( let file of files){
     print(file);
}
//print(files);


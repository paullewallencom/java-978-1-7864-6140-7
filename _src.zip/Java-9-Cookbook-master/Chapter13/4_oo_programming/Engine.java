public class Engine{
	public String type;
	public int cylinders;
	public int displacement;

	public Engine(){}

	public Engine(String type, int cylinders, int displacement){
		this.type = type;
		this.cylinders = cylinders;
		this.displacement = displacement;
	}
}
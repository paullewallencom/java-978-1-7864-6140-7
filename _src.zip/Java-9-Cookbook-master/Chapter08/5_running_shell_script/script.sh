echo $MY_VARIABLE;
echo "Running tree command";
tree;
echo "Running iostat command"
iostat;
module book.manage{
	requires book.service;
}
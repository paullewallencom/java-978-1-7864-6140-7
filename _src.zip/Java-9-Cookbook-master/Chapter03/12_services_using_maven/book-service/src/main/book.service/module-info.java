module book.service{
	exports com.packt.model;
	exports com.packt.service;
	exports com.packt.spi;
	uses com.packt.spi.BookServiceProvider;
}
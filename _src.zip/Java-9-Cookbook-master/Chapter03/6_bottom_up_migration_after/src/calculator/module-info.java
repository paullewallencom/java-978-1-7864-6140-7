module calculator{ 
    requires math.util; 
    requires banking.util; 
    requires jackson.databind; 
    requires jackson.core; 
    requires jackson.annotations; 
}
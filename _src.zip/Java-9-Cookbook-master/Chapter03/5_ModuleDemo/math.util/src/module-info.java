/**
 * Created by sanaulla on 12/6/2016.
 */
module math.util {
    exports com.packt.math;
}
/**
 * Created by sanaulla on 12/6/2016.
 */
module calculator {
    requires math.util;
}
cp ../7_top_down_migration_before/calculator/lib/jackson-annotations-2.8.4.jar mlib/jackson.annotations.jar 

cp ../7_top_down_migration_before/calculator/lib/jackson-core-2.8.4.jar mlib/jackson.core.jar 

cp ../7_top_down_migration_before/calculator/lib/jackson-databind-2.8.4.jar mlib/jackson.databind.jar 

cp ../7_top_down_migration_before/banking_util/out/banking.util.jar mlib/ 

cp ../7_top_down_migration_before/math_util/out/math.util.jar mlib/
module http.client.demo{
    requires httpclient;
    requires httpcore;
    requires commons.logging;
    requires commons.codec;
    
}
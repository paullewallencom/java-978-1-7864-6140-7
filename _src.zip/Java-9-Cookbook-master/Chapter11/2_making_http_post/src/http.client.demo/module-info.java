module http.client.demo{
    requires jdk.incubator.httpclient;
    requires jackson.databind;
    requires jackson.core;
    requires jackson.annotations;
}
package com.packt.cookbook.ch15_testing.process;

public enum Process {
    AVERAGE_SPEED,
    TRAFFIC_DENSITY
}

package com.packt.cookbook.ch02_oop.e_interface.b.api;

public interface Vehicle {
    void setSpeedModel(SpeedModel speedModel);
    double getSpeedMph(double timeSec);
}

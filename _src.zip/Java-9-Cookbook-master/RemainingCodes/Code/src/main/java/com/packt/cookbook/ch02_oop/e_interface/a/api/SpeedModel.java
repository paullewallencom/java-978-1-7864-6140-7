package com.packt.cookbook.ch02_oop.e_interface.a.api;

public interface SpeedModel {
    double getSpeedMph(double timeSec, int weightPounds, int horsePower);
}

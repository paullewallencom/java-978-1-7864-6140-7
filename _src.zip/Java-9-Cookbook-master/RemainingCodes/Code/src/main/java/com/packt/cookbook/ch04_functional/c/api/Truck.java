package com.packt.cookbook.ch04_functional.c.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}

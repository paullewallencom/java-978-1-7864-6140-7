package com.packt.cookbook.ch07_concurrency.api;

public interface Car extends Vehicle {
    int getPassengersCount();

}

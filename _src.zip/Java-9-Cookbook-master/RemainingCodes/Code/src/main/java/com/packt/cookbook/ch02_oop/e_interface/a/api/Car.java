package com.packt.cookbook.ch02_oop.e_interface.a.api;

public interface Car extends Vehicle {
    int getPassengersCount();
}

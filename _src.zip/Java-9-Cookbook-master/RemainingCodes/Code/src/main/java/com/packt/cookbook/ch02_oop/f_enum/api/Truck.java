package com.packt.cookbook.ch02_oop.f_enum.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}

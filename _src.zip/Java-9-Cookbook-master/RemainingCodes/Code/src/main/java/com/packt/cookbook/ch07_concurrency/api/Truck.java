package com.packt.cookbook.ch07_concurrency.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}

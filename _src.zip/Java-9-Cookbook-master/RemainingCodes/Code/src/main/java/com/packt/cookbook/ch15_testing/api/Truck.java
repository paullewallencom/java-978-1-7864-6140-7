package com.packt.cookbook.ch15_testing.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}

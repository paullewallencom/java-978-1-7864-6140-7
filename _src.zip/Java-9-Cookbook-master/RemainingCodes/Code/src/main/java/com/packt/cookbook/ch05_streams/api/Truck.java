package com.packt.cookbook.ch05_streams.api;

public interface Truck extends Vehicle {
    int getPayloadPounds();
}

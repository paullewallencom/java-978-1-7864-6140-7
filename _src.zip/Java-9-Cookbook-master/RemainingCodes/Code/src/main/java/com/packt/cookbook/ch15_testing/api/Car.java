package com.packt.cookbook.ch15_testing.api;

public interface Car extends Vehicle {
    int getPassengersCount();

}

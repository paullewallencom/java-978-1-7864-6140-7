package com.packt.cookbook.ch05_streams.api;

public interface Car extends Vehicle {
    int getPassengersCount();

}
